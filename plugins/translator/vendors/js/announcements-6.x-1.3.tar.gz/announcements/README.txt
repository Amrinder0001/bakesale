$Id: README.txt,v 1.1.4.1 2008/05/20 02:13:55 nancyw Exp $

This is an adaptation of the sample module writing article at
http://www-128.ibm.com/developerworks/ibm/library/i-osource6/.

This module creates an "announcements" content type and provides both node
views and block lists.

Normal module installation applies.